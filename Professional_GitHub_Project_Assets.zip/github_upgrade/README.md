
# 🚀 Automated Resume Screening Tool

AI-powered Resume Screening Tool using Python, NLP, TF-IDF, Cosine Similarity, FastAPI, and Streamlit.

---

# 📌 Project Overview

This project automatically screens resumes based on job descriptions.
It extracts text from resumes, cleans data, matches skills, calculates similarity scores,
and ranks candidates.

---

# ✨ Features

✅ Resume Parsing (PDF/DOCX)  
✅ Skill Extraction  
✅ TF-IDF Vectorization  
✅ Cosine Similarity Matching  
✅ Resume Ranking  
✅ CSV Report Generation  
✅ FastAPI Backend  
✅ Streamlit Dashboard  

---

# 🛠 Tech Stack

- Python
- Pandas
- NumPy
- Scikit-learn
- FastAPI
- Streamlit
- pdfplumber
- python-docx

---

# 📂 Folder Structure

```bash
Automated-Resume-Screening-Tool/
│
├── resumes/
├── data/
├── outputs/
├── src/
├── api/
├── dashboard/
├── images/
├── README.md
├── requirements.txt
└── main.py
```

---

# ⚙️ System Architecture

![Architecture](images/architecture_flowchart.png)

---

# 📊 Dashboard Preview

![Dashboard](images/dashboard_preview.png)

---

# ▶️ Run Commands

```bash
pip install -r requirements.txt

python main.py

streamlit run dashboard/streamlit_app.py

uvicorn api.app:app --reload
```

---

# 📈 Sample Output

| Resume | Score | Status |
|---|---|---|
| Rahul.pdf | 88% | Shortlisted |
| Aman.pdf | 74% | Shortlisted |
| Riya.pdf | 42% | Rejected |

---

# 💡 Future Improvements

- OpenAI Embeddings
- OCR Resume Parsing
- LinkedIn Integration
- Docker Deployment
- PostgreSQL Database

---

# 👨‍💻 Author

Jatin Pilani


import streamlit as st

st.title("Automated Resume Screening Tool")
st.write("Dashboard Running Successfully")

import re

def clean_resume(text):
    text = re.sub(r'http\S+', ' ', text)
    text = re.sub(r'[^A-Za-z0-9 ]+', ' ', text)
    return text.lower()

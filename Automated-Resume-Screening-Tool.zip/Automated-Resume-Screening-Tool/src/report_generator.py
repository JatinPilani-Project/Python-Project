import pandas as pd

def generate_report(results):
    df = pd.DataFrame(results)
    df.to_csv("outputs/ranking_report.csv", index=False)

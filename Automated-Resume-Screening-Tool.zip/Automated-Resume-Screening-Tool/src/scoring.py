from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def calculate_similarity(resume, jd):
    tfidf = TfidfVectorizer()
    matrix = tfidf.fit_transform([resume, jd])
    score = cosine_similarity(matrix[0:1], matrix[1:2])
    return round(float(score[0][0]) * 100, 2)

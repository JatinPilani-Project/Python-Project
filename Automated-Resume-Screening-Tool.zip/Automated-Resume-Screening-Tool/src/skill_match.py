skills = ["python", "sql", "pandas", "numpy", "machine learning"]

def extract_skills(text):
    found = []
    for skill in skills:
        if skill in text.lower():
            found.append(skill)
    return found
